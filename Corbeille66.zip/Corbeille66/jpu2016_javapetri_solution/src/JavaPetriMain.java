import jpu2016.javapetri.controller.JavaPetriController;

public abstract class JavaPetriMain {

	public static void main(final String[] args) {
		new JavaPetriController().start();
	}
}
